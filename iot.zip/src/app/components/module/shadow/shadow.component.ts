import { Component, OnInit } from '@angular/core';
import { ActivatedRoute} from '@angular/router';
import {ServiceService} from '../../../service.service'
@Component({
  selector: 'app-shadow',
  templateUrl: './shadow.component.html',
  styleUrls: ['./shadow.component.css']
})
export class ShadowComponent implements OnInit {
  public deviceid:any;
  public modulenameArr=[];
  public modulename:any;
  public listOfData:any;
  public groupid:any;
  public getDevice:any;
  public modelid:any;
  public modelname:any;
  public linklist:any[]=[]
  public link:any[]=[];
  public rw:any={}
  constructor(private route: ActivatedRoute,public service:ServiceService) { }

  async ngOnInit() {
    this.route.params.subscribe(async data=>{
      this.deviceid=data['deviceid']
      this.modulenameArr=data['modulename'].split(',')
      this.groupid=data['groupid']
    })
    this.getDevice=JSON.parse(JSON.stringify(await this.service.getModule(this.deviceid)))
  }
  async getLink(data:any){
    this.linklist=[]
    this.modelid=data.model_id;
    this.modulename=data.module_name
    let attrs=JSON.parse(JSON.stringify(await this.service.getAttr(this.modelid)))
    let temp:any[]=[];
    for(let i=0;i<attrs.length;i++){
      temp.push(attrs[i].attr_name)
      this.rw[attrs[i].attr_name]=attrs[i].rw
    }
      let demo=JSON.parse(JSON.stringify(await this.service.getDeviceShadow(this.deviceid,this.modulename,temp)))
      for(let i in demo){
        this.linklist.push({attr_name:i,time:demo[i]['Time'],value:demo[i]['Value']})
      }
      console.log(this.linklist);
      
  }

}

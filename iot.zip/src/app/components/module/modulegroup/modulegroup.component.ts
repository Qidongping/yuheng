import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modulegroup',
  templateUrl: './modulegroup.component.html',
  styleUrls: ['./modulegroup.component.css']
})
export class ModulegroupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
